from distutils.core import setup

setup(name='KafNafParser',
      version='1.0',
      description = 'Parser between KAF and NAF',
      author = 'Ruben Izquierdo',
      url = 'https://github.com/cltl/KafNafParserPy',
      author_email = 'r.izquierdobevia@vu.nl',
      package_dir = {'':''},
      packages = ["feature_extractor"],
      py_modules = ["header_data", "text_data", "term_data", "entity_data",
        "features_data", "opinion_data", "constituency_data", "dependency_data",
        "coreference_data", "references_data",
        "external_references_data", "span_data"],
      data_files = [ ('',['kaf_example.xml','naf.dtd','naf_example.xml',
        'test.py','README.md','LICENSE'])]
      )



